# Sales listing draft (for Gumroad, itch.io, or similar)

Copy-paste starting point — edit to your voice before publishing. You own the
actual storefront/payment account; this is just the words.

---

## Title
camscan — find and test every IP camera on your network in one command

## Short description (for listing card)
A command-line tool that scans your LAN for IP cameras and checks whether
their RTSP streams actually work — before you wire them into your NVR.

## Full description

Setting up or troubleshooting a security camera system usually means digging
through router admin pages, guessing IP addresses, and hunting for the right
RTSP URL in a PDF manual. camscan does that for you.

Run one command and get:
- Every device on your subnet with a camera-like port open
- Automatic ONVIF discovery for cameras that broadcast themselves
- A live check of each stream's actual codec, resolution, and frame rate
- Automatic testing of common RTSP path conventions (Hikvision, Dahua,
  Reolink-style, and generic paths) so you don't have to guess
- A JSON or CSV report you can save, hand to a client, or keep for your docs

Built for security camera installers, IT techs setting up NVRs, and anyone
doing DIY home camera installs who's tired of guessing RTSP URLs.

**Requires:** Python 3.9+, and `ffmpeg` on your system PATH for stream
testing (scanning works without it). A no-Python-needed Windows install is
also available.

## Price suggestion
$15–$25 one-time. This is a narrow professional/DIY utility, not mass-market
— price for the niche, not for volume.

## Suggested tags
rtsp, onvif, ip-camera, nvr, security-camera, cli-tool, network-tool,
sysadmin, home-automation
