import json
import subprocess
from unittest.mock import patch, MagicMock

import pytest

from camscan.probe import (
    probe_stream,
    build_candidate_urls,
    _parse_fps,
    FFprobeNotFoundError,
)


FAKE_FFPROBE_OUTPUT = json.dumps({
    "streams": [
        {"codec_type": "video", "codec_name": "h264", "width": 1920, "height": 1080, "avg_frame_rate": "25/1"},
        {"codec_type": "audio", "codec_name": "aac"},
    ]
})


def test_parse_fps_fraction():
    assert _parse_fps("25/1") == 25.0
    assert _parse_fps("30000/1001") == 29.97


def test_parse_fps_zero_denominator_returns_none():
    assert _parse_fps("0/0") is None


def test_parse_fps_none_input():
    assert _parse_fps(None) is None


def test_probe_stream_success():
    fake_proc = MagicMock(returncode=0, stdout=FAKE_FFPROBE_OUTPUT, stderr="")
    with patch("camscan.probe.shutil.which", return_value="/usr/bin/ffprobe"), \
         patch("camscan.probe.subprocess.run", return_value=fake_proc):
        info = probe_stream("rtsp://10.0.0.5:554/stream1")

    assert info.reachable is True
    assert info.codec == "h264"
    assert info.width == 1920
    assert info.height == 1080
    assert info.fps == 25.0
    assert info.has_audio is True


def test_probe_stream_unreachable_nonzero_exit():
    fake_proc = MagicMock(returncode=1, stdout="", stderr="Connection refused")
    with patch("camscan.probe.shutil.which", return_value="/usr/bin/ffprobe"), \
         patch("camscan.probe.subprocess.run", return_value=fake_proc):
        info = probe_stream("rtsp://10.0.0.99:554/stream1")

    assert info.reachable is False
    assert "Connection refused" in info.error


def test_probe_stream_timeout():
    with patch("camscan.probe.shutil.which", return_value="/usr/bin/ffprobe"), \
         patch("camscan.probe.subprocess.run", side_effect=subprocess.TimeoutExpired(cmd="ffprobe", timeout=8)):
        info = probe_stream("rtsp://10.0.0.99:554/stream1", timeout=8)

    assert info.reachable is False
    assert "Timed out" in info.error


def test_probe_stream_no_video_stream_present():
    audio_only = json.dumps({"streams": [{"codec_type": "audio", "codec_name": "aac"}]})
    fake_proc = MagicMock(returncode=0, stdout=audio_only, stderr="")
    with patch("camscan.probe.shutil.which", return_value="/usr/bin/ffprobe"), \
         patch("camscan.probe.subprocess.run", return_value=fake_proc):
        info = probe_stream("rtsp://10.0.0.5:554/audio-only")

    assert info.reachable is True
    assert info.codec is None
    assert info.has_audio is True
    assert "No video stream" in info.error


def test_probe_stream_ffprobe_missing_raises():
    with patch("camscan.probe.shutil.which", return_value=None):
        with pytest.raises(FFprobeNotFoundError):
            probe_stream("rtsp://10.0.0.5:554/stream1")


def test_build_candidate_urls_no_auth():
    urls = build_candidate_urls("10.0.0.5")
    assert all(u.startswith("rtsp://10.0.0.5:554") for u in urls)
    assert "@" not in urls[0]


def test_build_candidate_urls_with_auth():
    urls = build_candidate_urls("10.0.0.5", username="admin", password="secret123")
    assert all("admin:secret123@10.0.0.5" in u for u in urls)
