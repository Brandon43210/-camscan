from unittest.mock import patch

from camscan.scanner import (
    scan_host,
    scan_subnet,
    merge_discovery,
    DeviceResult,
    CAMERA_PORTS,
)


def test_check_port_open_marks_device_as_camera_like():
    def fake_connect_ex(self, addr):
        return 0 if addr[1] == 554 else 1

    with patch("socket.socket.connect_ex", fake_connect_ex):
        result = scan_host("10.0.0.5", ports=list(CAMERA_PORTS.keys()), timeout=0.01)

    assert result.ip == "10.0.0.5"
    assert 554 in result.open_ports
    assert result.likely_camera is True


def test_check_port_all_closed_not_likely_camera():
    with patch("socket.socket.connect_ex", return_value=1):
        result = scan_host("10.0.0.6", ports=[554, 80], timeout=0.01)

    assert result.open_ports == []
    assert result.likely_camera is False


def test_scan_subnet_only_returns_hosts_with_open_ports():
    def fake_connect_ex(self, addr):
        ip, port = addr
        return 0 if ip == "10.0.0.2" and port == 554 else 1

    with patch("socket.socket.connect_ex", fake_connect_ex):
        results = scan_subnet("10.0.0.0/30", ports=[554], timeout=0.01, max_workers=4)

    ips = [r.ip for r in results]
    assert ips == ["10.0.0.2"]


def test_merge_discovery_adds_new_onvif_only_device():
    existing = [DeviceResult(ip="10.0.0.5", open_ports=[554])]
    merged = merge_discovery(existing, onvif_ips=["10.0.0.5", "10.0.0.9"])

    by_ip = {r.ip: r for r in merged}
    assert by_ip["10.0.0.5"].onvif_discovered is True
    assert by_ip["10.0.0.5"].open_ports == [554]
    assert by_ip["10.0.0.9"].onvif_discovered is True
    assert by_ip["10.0.0.9"].open_ports == []
    assert len(merged) == 2


def test_merge_discovery_sorted_by_ip():
    existing = [DeviceResult(ip="10.0.0.20", open_ports=[80])]
    merged = merge_discovery(existing, onvif_ips=["10.0.0.3"])
    assert [r.ip for r in merged] == ["10.0.0.3", "10.0.0.20"]
