# camscan

Find every IP camera on your local network and check whether its RTSP stream
actually works — from the command line, in seconds. No NVR software, no
vendor app, no GUI required.

Built for installers, integrators, and DIYers setting up or troubleshooting
security camera systems, NVRs, and ONVIF devices.

## What it does

- **Scans your subnet** for devices with camera-like ports open (RTSP 554,
  common HTTP/ONVIF ports, and known Hikvision/Dahua proprietary ports).
- **Listens for ONVIF WS-Discovery** broadcasts to catch cameras that
  advertise themselves on the network.
- **Probes RTSP streams directly** (via `ffprobe`) to report codec,
  resolution, frame rate, and whether audio is present — so you know a
  stream actually plays before you wire it into your NVR.
- **Tries common RTSP paths automatically** (Hikvision, Dahua, Reolink-style,
  and generic paths) so you don't have to dig through a manual just to find
  the right URL.
- **Exports** results to JSON or CSV for documentation or handoff.

## Install

### Mac / Linux / Windows, with Python already installed

```bash
pip install camscan
```

Requires `ffmpeg`/`ffprobe` on your system PATH for stream probing (scanning
alone doesn't need it). On most systems: `apt install ffmpeg`,
`brew install ffmpeg`, or download from ffmpeg.org.

**Note:** this only works once the package is published to PyPI. Until then,
install from a local wheel or from source — see below.

### Windows, no separate Python or PyPI publish needed

Use `install-windows.bat` (included in this repo / the Windows install
download). It finds and installs from whichever of these it can:
1. a `camscan-*.whl` file sitting next to it, or
2. this project's source folder (`pyproject.toml`), building the wheel
   itself with pip.

It also checks for Python and ffmpeg and tells you what's missing.
**Important:** extract the zip fully first (right-click → Extract All) —
running the script directly out of a zip preview will fail because Windows
only copies that one file to a temp folder.

### Standalone binary, no Python needed at all

Each OS's binary must be built on that OS (PyInstaller doesn't cross-compile
from Linux to Windows). The included GitHub Actions workflow
(`.github/workflows/build-binaries.yml`) builds Windows, macOS, and Linux
binaries automatically on tagged releases — see the project's GitHub
Releases page once it's set up.

## Usage

Find every camera-like device on your LAN:

```bash
camscan scan 192.168.1.0/24
```

Do the same, and also try to open each one's video stream:

```bash
camscan scan 192.168.1.0/24 --probe --user admin --password yourpassword
```

Check one specific stream URL you already have:

```bash
camscan probe rtsp://192.168.1.50:554/stream1
```

Save a report for your records:

```bash
camscan scan 192.168.1.0/24 --probe --json report.json --csv report.csv
```

## Notes and limitations

- ONVIF WS-Discovery only finds cameras on the same network segment as the
  machine running camscan — it will not discover devices across routers or
  VLANs. Port scanning still works across routed subnets if you have access.
- `--probe` tries a handful of common RTSP path conventions per device. If a
  camera uses a non-standard path, use `camscan probe` directly with the
  exact URL from the camera's documentation.
- Scanning a subnet touches every host in the range — only run this against
  networks you own or have permission to scan.

## License

MIT
