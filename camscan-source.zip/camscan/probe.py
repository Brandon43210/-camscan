"""
Stream probing via ffprobe.

Given an RTSP URL, ask ffprobe for the video stream's codec, resolution,
frame rate, and whether an audio stream is present. Requires ffmpeg/ffprobe
to be installed on the host machine.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass
from typing import Optional


class FFprobeNotFoundError(RuntimeError):
    pass


@dataclass
class StreamInfo:
    url: str
    reachable: bool
    codec: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None
    fps: Optional[float] = None
    has_audio: bool = False
    error: Optional[str] = None


def _ffprobe_path() -> str:
    path = shutil.which("ffprobe")
    if not path:
        raise FFprobeNotFoundError(
            "ffprobe was not found on PATH. Install ffmpeg "
            "(https://ffmpeg.org/download.html) and try again."
        )
    return path


def _parse_fps(rate_str: Optional[str]) -> Optional[float]:
    if not rate_str or rate_str == "0/0":
        return None
    try:
        if "/" in rate_str:
            num, denom = rate_str.split("/")
            denom = float(denom)
            return round(float(num) / denom, 2) if denom else None
        return float(rate_str)
    except (ValueError, ZeroDivisionError):
        return None


def probe_stream(url: str, timeout: float = 8.0) -> StreamInfo:
    """
    Probe a single RTSP (or other ffmpeg-readable) stream URL.

    Uses `ffprobe -rtsp_transport tcp` for reliability over flaky/NAT'd
    networks, with a hard timeout so a dead camera doesn't hang the scan.
    """
    ffprobe = _ffprobe_path()
    cmd = [
        ffprobe,
        "-v", "error",
        "-rtsp_transport", "tcp",
        "-print_format", "json",
        "-show_streams",
        "-timeout", str(int(timeout * 1_000_000)),  # ffprobe wants microseconds
        url,
    ]

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout + 3,
        )
    except subprocess.TimeoutExpired:
        return StreamInfo(url=url, reachable=False, error="Timed out connecting to stream")

    if proc.returncode != 0:
        err = proc.stderr.strip() or "ffprobe failed to read stream"
        return StreamInfo(url=url, reachable=False, error=err[:300])

    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError:
        return StreamInfo(url=url, reachable=False, error="Could not parse ffprobe output")

    streams = data.get("streams", [])
    video = next((s for s in streams if s.get("codec_type") == "video"), None)
    has_audio = any(s.get("codec_type") == "audio" for s in streams)

    if not video:
        return StreamInfo(url=url, reachable=True, has_audio=has_audio, error="No video stream found")

    return StreamInfo(
        url=url,
        reachable=True,
        codec=video.get("codec_name"),
        width=video.get("width"),
        height=video.get("height"),
        fps=_parse_fps(video.get("avg_frame_rate") or video.get("r_frame_rate")),
        has_audio=has_audio,
    )


COMMON_RTSP_PATHS = [
    "/stream1", "/live", "/live/ch0", "/Streaming/Channels/101",
    "/cam/realmonitor?channel=1&subtype=0", "/h264Preview_01_main", "/",
]


def build_candidate_urls(ip: str, port: int = 554, username: str = "", password: str = "") -> list:
    """Build a list of likely RTSP URLs to try for an unidentified camera."""
    auth = f"{username}:{password}@" if username else ""
    return [f"rtsp://{auth}{ip}:{port}{path}" for path in COMMON_RTSP_PATHS]
