"""
camscan CLI - find IP cameras on your local network and check their streams.

Usage:
    camscan scan 192.168.1.0/24
    camscan scan 192.168.1.0/24 --probe --user admin --password admin123
    camscan probe rtsp://192.168.1.50:554/stream1
    camscan scan 192.168.1.0/24 --json out.json
    camscan scan 192.168.1.0/24 --csv out.csv
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from dataclasses import asdict

from . import __version__
from .scanner import scan_subnet, ws_discover, merge_discovery, DeviceResult
from .probe import probe_stream, build_candidate_urls, FFprobeNotFoundError, StreamInfo


def _print_scan_table(results: list[DeviceResult]) -> None:
    if not results:
        print("No devices with camera-like open ports were found.")
        return
    print(f"{'IP ADDRESS':<16} {'ONVIF':<7} {'OPEN PORTS':<30}")
    print("-" * 55)
    for r in results:
        onvif = "yes" if r.onvif_discovered else "no"
        ports = ", ".join(str(p) for p in r.open_ports) if r.open_ports else "-"
        print(f"{r.ip:<16} {onvif:<7} {ports:<30}")
    print(f"\n{len(results)} candidate device(s) found.")


def _print_probe_result(info: StreamInfo) -> None:
    if not info.reachable:
        print(f"  [FAIL] {info.url}\n         {info.error}")
        return
    if info.codec is None:
        print(f"  [WARN] {info.url}\n         Reachable, but {info.error or 'no video stream'}")
        return
    audio = "yes" if info.has_audio else "no"
    fps = f"{info.fps}fps" if info.fps else "fps unknown"
    print(f"  [OK]   {info.url}")
    print(f"         {info.codec}, {info.width}x{info.height}, {fps}, audio: {audio}")


def cmd_scan(args: argparse.Namespace) -> int:
    print(f"Scanning {args.cidr} for camera-like open ports...")
    results = scan_subnet(args.cidr, timeout=args.timeout, max_workers=args.workers)

    if not args.no_onvif:
        print("Sending ONVIF WS-Discovery probe...")
        try:
            onvif_ips = ws_discover(timeout=args.onvif_timeout)
            results = merge_discovery(results, onvif_ips)
        except OSError as e:
            print(f"  (ONVIF discovery skipped: {e})")

    _print_scan_table(results)

    probed = []
    if args.probe:
        print("\nProbing candidate RTSP streams (this may take a while)...")
        try:
            for r in results:
                if not r.likely_camera:
                    continue
                print(f"\n{r.ip}:")
                port = 554 if 554 in r.open_ports else (8554 if 8554 in r.open_ports else 554)
                candidates = build_candidate_urls(r.ip, port, args.user or "", args.password or "")
                found_working = False
                for url in candidates:
                    info = probe_stream(url, timeout=args.probe_timeout)
                    if info.reachable and info.codec:
                        _print_probe_result(info)
                        probed.append(info)
                        found_working = True
                        break
                if not found_working:
                    print(f"  No working stream path found among {len(candidates)} common paths tried.")
                    print(f"  Check the camera's manual for its exact RTSP path.")
        except FFprobeNotFoundError as e:
            print(f"\nCannot probe streams: {e}")

    if args.json:
        payload = {
            "devices": [asdict(r) for r in results],
            "probed_streams": [asdict(p) for p in probed],
        }
        with open(args.json, "w") as f:
            json.dump(payload, f, indent=2)
        print(f"\nJSON report written to {args.json}")

    if args.csv:
        with open(args.csv, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["ip", "onvif_discovered", "open_ports"])
            for r in results:
                writer.writerow([r.ip, r.onvif_discovered, " ".join(str(p) for p in r.open_ports)])
        print(f"CSV report written to {args.csv}")

    return 0


def cmd_probe(args: argparse.Namespace) -> int:
    try:
        info = probe_stream(args.url, timeout=args.timeout)
    except FFprobeNotFoundError as e:
        print(str(e))
        return 1
    _print_probe_result(info)
    return 0 if info.reachable and info.codec else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="camscan",
        description="Find IP cameras on your local network and check their RTSP streams.",
    )
    parser.add_argument("--version", action="version", version=f"camscan {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    p_scan = sub.add_parser("scan", help="Scan a subnet for camera-like devices")
    p_scan.add_argument("cidr", help="CIDR range to scan, e.g. 192.168.1.0/24")
    p_scan.add_argument("--probe", action="store_true", help="Also try to open each candidate's RTSP stream")
    p_scan.add_argument("--user", help="Username to try when probing streams")
    p_scan.add_argument("--password", help="Password to try when probing streams")
    p_scan.add_argument("--timeout", type=float, default=0.5, help="Per-port scan timeout in seconds (default 0.5)")
    p_scan.add_argument("--probe-timeout", type=float, default=8.0, help="Per-stream probe timeout in seconds (default 8)")
    p_scan.add_argument("--onvif-timeout", type=float, default=3.0, help="ONVIF discovery listen window in seconds (default 3)")
    p_scan.add_argument("--workers", type=int, default=100, help="Concurrent scan workers (default 100)")
    p_scan.add_argument("--no-onvif", action="store_true", help="Skip ONVIF WS-Discovery multicast probe")
    p_scan.add_argument("--json", metavar="FILE", help="Write a JSON report to FILE")
    p_scan.add_argument("--csv", metavar="FILE", help="Write a CSV report to FILE")
    p_scan.set_defaults(func=cmd_scan)

    p_probe = sub.add_parser("probe", help="Probe a single RTSP URL directly")
    p_probe.add_argument("url", help="RTSP URL to probe, e.g. rtsp://192.168.1.50:554/stream1")
    p_probe.add_argument("--timeout", type=float, default=8.0, help="Probe timeout in seconds (default 8)")
    p_probe.set_defaults(func=cmd_probe)

    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        print("\nInterrupted.")
        return 130


if __name__ == "__main__":
    sys.exit(main())
