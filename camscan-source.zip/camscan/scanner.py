"""
Network scanning logic for camscan.

Finds devices on the local subnet that look like IP cameras by checking
for commonly-open camera ports (RTSP 554, HTTP 80, ONVIF 8080/8899, etc.)
and, optionally, ONVIF WS-Discovery multicast responses.
"""
from __future__ import annotations

import ipaddress
import socket
import concurrent.futures
from dataclasses import dataclass, field
from typing import List, Optional

# Ports commonly used by IP cameras / NVRs.
CAMERA_PORTS = {
    554: "RTSP",
    8554: "RTSP-alt",
    80: "HTTP",
    8080: "HTTP-alt/ONVIF",
    8000: "HTTP-alt",
    37777: "Dahua-proprietary",
    34567: "Hikvision-proprietary",
}

WS_DISCOVERY_MSG = (
    b'<?xml version="1.0" encoding="UTF-8"?>'
    b'<e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope" '
    b'xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing" '
    b'xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery" '
    b'xmlns:dn="http://www.onvif.org/ver10/network/wsdl">'
    b"<e:Header>"
    b"<w:MessageID>uuid:84ede3de-7dec-11d0-c360-f01234567890</w:MessageID>"
    b"<w:To e:mustUnderstand=\"true\">urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To>"
    b"<w:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action>"
    b"</e:Header>"
    b"<e:Body>"
    b'<d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types></d:Probe>'
    b"</e:Body></e:Envelope>"
)
WS_DISCOVERY_MULTICAST_ADDR = "239.255.255.250"
WS_DISCOVERY_PORT = 3702


@dataclass
class DeviceResult:
    ip: str
    open_ports: List[int] = field(default_factory=list)
    onvif_discovered: bool = False

    @property
    def likely_camera(self) -> bool:
        return self.onvif_discovered or 554 in self.open_ports or 8554 in self.open_ports


def _check_port(ip: str, port: int, timeout: float) -> bool:
    """Return True if the given TCP port is open on ip."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            result = s.connect_ex((ip, port))
            return result == 0
    except OSError:
        return False


def scan_host(ip: str, ports=None, timeout: float = 0.5) -> DeviceResult:
    """Check a single host for open camera-relevant ports."""
    ports = ports or list(CAMERA_PORTS.keys())
    open_ports = [p for p in ports if _check_port(ip, p, timeout)]
    return DeviceResult(ip=ip, open_ports=open_ports)


def scan_subnet(
    cidr: str,
    ports: Optional[List[int]] = None,
    timeout: float = 0.5,
    max_workers: int = 100,
) -> List[DeviceResult]:
    """
    Scan every host in a CIDR range for open camera ports.

    Only hosts with at least one relevant open port are returned.
    """
    network = ipaddress.ip_network(cidr, strict=False)
    hosts = [str(h) for h in network.hosts()]

    results: List[DeviceResult] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(scan_host, ip, ports, timeout): ip for ip in hosts}
        for fut in concurrent.futures.as_completed(futures):
            res = fut.result()
            if res.open_ports:
                results.append(res)

    results.sort(key=lambda r: tuple(int(x) for x in r.ip.split(".")))
    return results


def ws_discover(timeout: float = 3.0) -> List[str]:
    """
    Send an ONVIF WS-Discovery probe over multicast and collect responding IPs.

    Returns a list of IP addresses that responded. Requires the host machine
    to be on the same L2 network segment as the cameras (standard ONVIF
    discovery does not cross routers/VLANs).
    """
    found: List[str] = []
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
    sock.settimeout(timeout)

    try:
        sock.sendto(WS_DISCOVERY_MSG, (WS_DISCOVERY_MULTICAST_ADDR, WS_DISCOVERY_PORT))
        while True:
            try:
                _, addr = sock.recvfrom(65535)
                ip = addr[0]
                if ip not in found:
                    found.append(ip)
            except socket.timeout:
                break
    finally:
        sock.close()

    return found


def merge_discovery(scan_results: List[DeviceResult], onvif_ips: List[str]) -> List[DeviceResult]:
    """Merge WS-Discovery results into the port-scan results list."""
    by_ip = {r.ip: r for r in scan_results}
    for ip in onvif_ips:
        if ip in by_ip:
            by_ip[ip].onvif_discovered = True
        else:
            by_ip[ip] = DeviceResult(ip=ip, open_ports=[], onvif_discovered=True)
    merged = list(by_ip.values())
    merged.sort(key=lambda r: tuple(int(x) for x in r.ip.split(".")))
    return merged
